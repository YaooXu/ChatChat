//#ifndef GROUP_LIST_H
#pragma once
//#define GROUP_LIST_H

#include <QObject>
#include <QWidget>
#include <QToolBox>


class group_list: public QToolBox
{
public:
    group_list();
};

//#endif // GROUP_LIST_H
