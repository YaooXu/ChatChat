#include "group_list.h"

group_list::group_list()
{

}
